# Loan Recovery AI Calling Agent (CSV → Auto Calls)

This is a minimal, production-ready starter that:
- Lets you upload a CSV of customers
- Places **automated voice calls** to each number using **Twilio Programmable Voice**
- Reads a dynamic **Hindi-English (Hinglish)** recovery script with each customer's details
- Includes **DRY_RUN mode** for safe testing (no real calls)
- Simple web UI + Flask backend

> ⚠️ Compliance: Call only to customers who have consented. In India, follow TRAI/DND rules, registered headers, and approved templates. Respect opt-outs.

---

## 1) Project Structure
```
ai-recovery-agent/
├─ app.py
├─ requirements.txt
├─ .env.example
├─ templates/
│  └─ index.html
├─ static/
│  └─ script.js
└─ sample_customers.csv
```

## 2) Environment Variables
Copy `.env.example` to `.env` and set your values.
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_NUMBER=+1xxxxxxxxxx         # Your Twilio caller ID (verified/approved)
COMPANY_NAME=SBFC Finance Ltd
OFFICER_NAME=Salman
OFFICER_NUMBER=+918433897772       # For callback prompt
DRY_RUN=true                       # 'true' (no real calls) or 'false' (place calls)
```

## 3) Installing & Running (Local)
```bash
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Visit: http://127.0.0.1:5000

> If DRY_RUN=true, the app **won't call**; it will **simulate** and log.

## 4) CSV Format
`sample_customers.csv` included. Columns supported:
```
name,phone,loan_no,amount,due_date,bucket,insured
```
- `phone` must include country code (e.g., +91XXXXXXXXXX).

## 5) Deploy (Render/Railway/VPS)
- Push this folder to GitHub.
- Create a new **Web Service** on Render/Railway.
- Build Command: `pip install -r requirements.txt`
- Start Command: `python app.py`
- Set env vars in dashboard.
- Expose port 5000 (Render auto-detects `PORT` env and app uses it).

## 6) Customize the Call Script
Edit the function `build_script(payload)` in `app.py`. It returns the speech text each call will read out (Hinglish).

## 7) Legal/Consent & Best Practices
- Call only customers with consent; respect DND.
- Keep **retry limits**; avoid harassment.
- Log outcomes; honor **STOP/Do-Not-Call** requests quickly.
- Use **DRY_RUN** for testing before going live.
